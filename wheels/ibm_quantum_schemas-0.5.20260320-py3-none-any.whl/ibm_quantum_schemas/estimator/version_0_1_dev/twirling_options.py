# This code is a Qiskit project.
#
# (C) Copyright IBM 2026.
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE.txt file in the root directory
# of this source tree or at http://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

"""Twirling Options Model"""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, Field

TwirlingStrategyType = Literal[
    "active",
    "active-accum",
    "active-circuit",
    "all",
]


class TwirlingOptionsModel(BaseModel):
    """Twirling options."""

    enable_gates: bool | None = None
    """Whether to apply 2-qubit Clifford gate twirling.

    If ``enables_gates`` is ``None``, it is determined by the server according to the
    resilience level: it is ``False`` for resilience levels 0 and 1, and ``True`` for resilience
    level 2.
    """

    enable_measure: bool | None = None
    """Whether to enable twirling to measurement instructions, as long as the measurement is not
    involved within a conditional block.

    If ``enable_measure`` is ``None``, it is determined by the server according to the
    resilience level: it is ``False`` for resilience level 0, and ``True`` for resilience
    levels 1 and 2.
    """

    num_randomizations: Annotated[int, Field(ge=1)] | Literal["auto"] = "auto"
    """The number of random samples to use when twirling or performing sampled mitigation.

    If ``num_randomizations`` is "auto", for every pub executed ``shots`` times:

      * If ``shots_per_randomization`` is also "auto", ``shots_per_randomization`` is set first
        as described below, then ``num_randomizations`` is set as
        ``ceil(shots/shots_per_randomization)``, where ``ceil`` is the ceiling function.
      * Otherwise, the value is set to ``ceil(shots/shots_per_randomization)``.

    .. note::
      The ``shots`` value specified in a PUB or in the ``run()`` method is
      considered part of the primitive execution interface and therefore is always
      obeyed. ``default_shots``, on the other hand, is considered a Qiskit Runtime
      specific option. Therefore, the product of ``num_randomizations`` and
      ``shots_per_randomization`` takes precedence over ``default_shots``.
    """

    shots_per_randomization: Annotated[int, Field(ge=1)] | Literal["auto"] = "auto"
    """The number of shots to run for each random sample.

    If "auto", for every pub executed ``shots`` times:

      * If ``num_randomizations`` is also "auto", the value is set to ``64`` for PEC mitigation
        or to ``max(64, ceil(shots / 32))`` in all other cases, where ``ceil`` is the ceiling
        function.
      * Otherwise, the value is set to ``ceil(shots/num_randomizations)``.

    .. note::
      The ``shots`` value specified in a PUB or in the ``run()`` method is
      considered part of the primitive execution interface and therefore is always
      obeyed. ``default_shots``, on the other hand, is considered a Qiskit Runtime
      specific option. Therefore, the product of ``num_randomizations`` and
      ``shots_per_randomization`` takes precedence over ``default_shots``.
    """

    strategy: TwirlingStrategyType = "active-accum"
    """Specify the strategy of twirling qubits in identified layers of 2-qubit twirled gates.

    Allowed values are:

      * If ``"active"`` only the instruction qubits in each individual twirled
        layer will be twirled.
      * If ``"active-circuit"`` the union of all instruction qubits in the circuit
        will be twirled in each twirled layer.
      * If ``"active-accum"`` the union of instructions qubits in the circuit up to
        the current twirled layer will be twirled in each individual twirled layer.
      * If ``"all"`` all qubits in the input circuit will be twirled in each
        twirled layer.
    """
